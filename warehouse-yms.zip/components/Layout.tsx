
import React, { useState } from 'react';
import { LayoutDashboard, BarChart2, LogOut, Truck, Menu, X, ChevronLeft, ChevronRight, Package, ShieldCheck } from 'lucide-react';

interface Props {
  children: React.ReactNode;
  view: string;
  onChangeView: (view: string) => void;
  isAdmin: boolean;
}

const Layout: React.FC<Props> = ({ children, view, onChangeView, isAdmin }) => {
  // Mobile menu state removed as we are forcing desktop view
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleSidebar = () => setIsCollapsed(!isCollapsed);

  // Helper for Nav Item
  const NavItem = ({ id, icon: Icon, label }: { id: string, icon: any, label: string }) => (
    <button 
        onClick={() => onChangeView(id)}
        title={isCollapsed ? label : ''}
        className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all duration-300 group relative
          ${view === id 
            ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-900/50' 
            : 'text-slate-400 hover:bg-white/5 hover:text-white'
          }
          ${isCollapsed ? 'justify-center' : ''}
        `}
    >
        <Icon className={`w-6 h-6 shrink-0 transition-transform duration-300 ${view === id && !isCollapsed ? 'animate-pulse' : ''} ${isCollapsed ? 'group-hover:scale-110' : ''}`} />
        
        <span className={`font-semibold whitespace-nowrap transition-all duration-300 origin-left 
            ${isCollapsed ? 'opacity-0 w-0 overflow-hidden scale-0' : 'opacity-100 w-auto scale-100'}
        `}>
            {label}
        </span>

        {/* Tooltip for Collapsed State */}
        {isCollapsed && (
            <div className="absolute left-full ml-4 px-3 py-1 bg-slate-800 text-white text-xs font-bold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-none shadow-xl border border-slate-700">
                {label}
            </div>
        )}
    </button>
  );

  if (!isAdmin) {
    // Driver / Public Layout (Standard)
    return (
      <div className="min-h-screen flex flex-col">
        <header className="sticky top-0 z-50 glass border-b border-white/20 transition-all duration-300">
          <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div 
              className="flex items-center gap-3 cursor-pointer group" 
              onClick={() => onChangeView('home')}
            >
                <div className="bg-gradient-to-br from-blue-600 to-indigo-600 text-white p-2 rounded-xl shadow-lg shadow-blue-500/30 group-hover:scale-110 transition-transform duration-300">
                    <Truck className="w-6 h-6" />
                </div>
                <span className="font-bold text-xl tracking-tight text-slate-800">
                  Warehouse<span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">YMS</span>
                </span>
            </div>
          </div>
        </header>
        <main className="flex-grow container mx-auto px-4 py-8 animate-fade-in-up">
          {children}
        </main>
        <footer className="glass border-t border-white/20 py-8 text-center text-sm text-slate-500 mt-auto">
            <p className="font-medium">&copy; 2024 Logistics Corp. <span className="text-blue-600">Premium Yard Management</span>.</p>
        </footer>
      </div>
    );
  }

  // Admin Layout (FORCED DESKTOP MODE)
  return (
    <div className="min-h-screen flex">
      {/* Sidebar Desktop - ALWAYS VISIBLE (Removed hidden md:flex) */}
      <aside 
        className={`glass-dark flex flex-col fixed h-full z-30 shadow-2xl transition-all duration-300 ease-in-out
            ${isCollapsed ? 'w-24' : 'w-72'}
        `}
      >
        {/* Toggle Button */}
        <button 
            onClick={toggleSidebar}
            className="absolute -right-3 top-10 bg-blue-600 text-white p-1 rounded-full shadow-lg border-2 border-slate-900 hover:bg-blue-500 transition-colors z-50"
        >
            {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>

        {/* Header */}
        <div className={`p-6 flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'} transition-all duration-300`}>
           <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white p-2.5 rounded-xl shadow-lg shadow-blue-500/20 shrink-0">
                <Truck className="w-7 h-7" />
            </div>
           <div className={`overflow-hidden transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100'}`}>
             <h1 className="font-black text-xl text-white tracking-wide whitespace-nowrap">YMS <span className="text-blue-400">ADMIN</span></h1>
             <p className="text-[10px] text-slate-400 font-bold tracking-widest whitespace-nowrap">CONTROL CENTER</p>
           </div>
        </div>
        
        {/* Navigation */}
        <nav className="flex-grow px-4 space-y-3 py-6 overflow-y-auto custom-scrollbar">
            <div className={`text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 transition-all ${isCollapsed ? 'text-center' : 'px-2'}`}>
                {isCollapsed ? 'OPS' : 'Divisi Operasional'}
            </div>
            <NavItem id="admin-dashboard" icon={LayoutDashboard} label="Dashboard Ops" />
            <NavItem id="admin-reports" icon={BarChart2} label="Laporan Harian" />
        </nav>
        
        {/* Footer / Logout */}
        <div className="p-4 border-t border-white/5">
            <button 
              onClick={() => onChangeView('home')} 
              title={isCollapsed ? "Logout" : ""}
              className={`flex items-center gap-3 text-slate-400 hover:text-red-400 transition-colors w-full px-4 py-3 rounded-xl hover:bg-white/5 group relative
                ${isCollapsed ? 'justify-center' : ''}
              `}
            >
                <LogOut className="w-6 h-6 shrink-0 group-hover:-translate-x-1 transition-transform" /> 
                <span className={`font-bold whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0 overflow-hidden' : 'w-auto opacity-100'}`}>
                    Logout
                </span>
            </button>
        </div>
      </aside>

      {/* NO MOBILE HEADER - Removed entirely */}

      {/* Main Content - Always margin-left'ed */}
      <main 
        className={`flex-1 min-h-screen bg-slate-50/50 transition-all duration-300 ease-in-out
            ${isCollapsed ? 'ml-24' : 'ml-72'}
        `}
      >
        <div className="p-8 max-w-[1920px] mx-auto animate-fade-in-up">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
