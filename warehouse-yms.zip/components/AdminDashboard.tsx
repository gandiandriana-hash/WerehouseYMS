
import React, { useEffect, useState } from 'react';
import { getDrivers, assignGate, updateStatus } from '../services/dataService';
import { DriverData, QueueStatus, Gate, Priority } from '../types';
import { 
  Users, Truck, ArrowRight, Bell, CheckCircle, 
  Clock, Search, XCircle, X, Activity, FileText, ArrowLeft, MoreHorizontal, Calendar, MapPin
} from 'lucide-react';

// --- SUB-COMPONENTS ---

interface DriverCardProps {
  driver: DriverData;
  onAssign: (id: string) => void;
  onStatusChange: (id: string, status: QueueStatus) => void;
}

const DriverCard: React.FC<DriverCardProps> = ({ driver, onAssign, onStatusChange }) => {
  const isUrgent = driver.priority === Priority.URGENT;
  
  // Dynamic border color based on status/gate
  const getBorderColor = () => {
      if (isUrgent) return 'border-l-red-500';
      if (driver.gate === Gate.GATE_2) return 'border-l-blue-500';
      if (driver.gate === Gate.GATE_4) return 'border-l-purple-500';
      return 'border-l-slate-300';
  };

  return (
    <div className={`bg-white rounded-xl p-3 shadow-sm border border-slate-200/60 relative group hover:shadow-md transition-all duration-200 border-l-[6px] ${getBorderColor()} flex flex-col h-full`}>
      
      {/* Header Card: Queue Number & Plate */}
      <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-2">
              <span className={`text-lg font-black tracking-tighter ${isUrgent ? 'text-red-600' : 'text-slate-800'}`}>
                  {driver.queueNumber || 'New'}
              </span>
              {isUrgent && (
                <span className="bg-red-100 text-red-600 text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 animate-pulse">
                    <Activity className="w-3 h-3" />
                </span>
              )}
          </div>
          <div className="text-right">
              <div className="bg-slate-100 text-slate-700 font-mono font-bold text-xs px-2 py-0.5 rounded border border-slate-200">
                  {driver.licensePlate}
              </div>
          </div>
      </div>

      {/* Driver Info */}
      <div className="mb-2 flex-grow">
          <h4 className="font-bold text-slate-800 text-sm leading-tight truncate" title={driver.name}>{driver.name}</h4>
          <p className="text-xs text-slate-500 font-medium truncate mb-2">{driver.company}</p>
          
          <div className="flex flex-wrap gap-1.5">
               <div className={`flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded border ${driver.purpose === 'LOADING' ? 'bg-blue-50 text-blue-700 border-blue-100' : 'bg-purple-50 text-purple-700 border-purple-100'}`}>
                  <Truck className="w-3 h-3" /> {driver.purpose.substring(0, 1)}
               </div>
               <div className="flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-50 text-slate-600 border border-slate-100 truncate max-w-[100px]" title={driver.doNumber}>
                  <FileText className="w-3 h-3" /> {driver.doNumber}
               </div>
          </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-2 border-t border-slate-100 flex gap-1.5 mt-auto">
          {driver.status === QueueStatus.UNASSIGNED && (
              <button onClick={() => onAssign(driver.id)} className="flex-1 py-1.5 bg-slate-900 text-white rounded-md font-bold text-[10px] hover:bg-slate-800 transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-95">
                  Set Gate <ArrowRight className="w-3 h-3" />
              </button>
          )}

          {driver.status === QueueStatus.WAITING && (
              <button onClick={() => onStatusChange(driver.id, QueueStatus.CALLED)} className="flex-1 py-1.5 bg-blue-600 text-white rounded-md font-bold text-[10px] hover:bg-blue-700 transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-95">
                  <Bell className="w-3 h-3" /> Panggil
              </button>
          )}

          {driver.status === QueueStatus.CALLED && (
              <button onClick={() => onStatusChange(driver.id, QueueStatus.LOADING)} className="flex-1 py-1.5 bg-emerald-500 text-white rounded-md font-bold text-[10px] hover:bg-emerald-600 transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-95 animate-pulse">
                  <Truck className="w-3 h-3" /> Start
              </button>
          )}

          {driver.status === QueueStatus.LOADING && (
              <button onClick={() => onStatusChange(driver.id, QueueStatus.COMPLETED)} className="flex-1 py-1.5 bg-slate-800 text-white rounded-md font-bold text-[10px] hover:bg-slate-900 transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-95">
                  <CheckCircle className="w-3 h-3" /> Selesai
              </button>
          )}

          {/* Cancel Button (Small) */}
          {driver.status !== QueueStatus.LOADING && driver.status !== QueueStatus.COMPLETED && (
               <button onClick={() => onStatusChange(driver.id, QueueStatus.CANCELLED)} className="w-7 h-auto flex items-center justify-center rounded-md bg-red-50 text-red-400 hover:bg-red-100 hover:text-red-600 transition-colors" title="Batalkan">
                  <XCircle className="w-4 h-4" />
               </button>
          )}
      </div>
    </div>
  );
};

interface Props {
    onBack?: () => void;
}

const AdminDashboard: React.FC<Props> = ({ onBack }) => {
  const [drivers, setDrivers] = useState<DriverData[]>([]);
  const [time, setTime] = useState(new Date());
  
  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [selectedDriverId, setSelectedDriverId] = useState<string | null>(null);
  const [selectedGate, setSelectedGate] = useState<Gate>(Gate.GATE_2);
  const [selectedPriority, setSelectedPriority] = useState<Priority>(Priority.NORMAL);

  const refreshData = () => {
    setDrivers(getDrivers());
    setTime(new Date());
  };

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 5000);
    return () => clearInterval(interval);
  }, []);

  // Filter Logic
  const filteredDrivers = drivers.filter(d => {
    const term = searchTerm.toLowerCase();
    const matchesSearch = 
        d.name.toLowerCase().includes(term) || 
        d.licensePlate.toLowerCase().includes(term) ||
        d.company.toLowerCase().includes(term);
    return matchesSearch;
  });

  const getQueueForGate = (gate: Gate) => {
    return filteredDrivers
      .filter(d => d.gate === gate && d.status !== QueueStatus.COMPLETED && d.status !== QueueStatus.CANCELLED && d.status !== QueueStatus.EXITED)
      .sort((a, b) => {
        if (a.priority === Priority.URGENT && b.priority === Priority.NORMAL) return -1;
        if (a.priority === Priority.NORMAL && b.priority === Priority.URGENT) return 1;
        // Called drivers on top within priority
        if (a.status === QueueStatus.CALLED && b.status !== QueueStatus.CALLED) return -1;
        if (b.status === QueueStatus.CALLED && a.status !== QueueStatus.CALLED) return 1;
        const timeA = a.assignmentTime || a.checkInTime;
        const timeB = b.assignmentTime || b.checkInTime;
        return timeA - timeB;
      });
  };

  const unassigned = filteredDrivers.filter(d => d.status === QueueStatus.UNASSIGNED || d.status === QueueStatus.BOOKED);
  const gate2Queue = getQueueForGate(Gate.GATE_2);
  const gate4Queue = getQueueForGate(Gate.GATE_4);

  // Modal Handlers
  const openAssignModal = (id: string) => {
      setSelectedDriverId(id);
      setIsAssignModalOpen(true);
      setSelectedGate(Gate.GATE_2);
      setSelectedPriority(Priority.NORMAL);
  };

  const closeAssignModal = () => {
      setIsAssignModalOpen(false);
      setSelectedDriverId(null);
  };

  const confirmAssign = () => {
      if (selectedDriverId) {
          assignGate(selectedDriverId, selectedGate, selectedPriority);
          refreshData();
          closeAssignModal();
      }
  };

  const handleStatusChange = (id: string, newStatus: QueueStatus) => {
      updateStatus(id, newStatus);
      refreshData();
  };

  // --- MODAL COMPONENT ---
  const AssignModal = () => {
      if (!isAssignModalOpen || !selectedDriverId) return null;
      const driver = drivers.find(d => d.id === selectedDriverId);
      if (!driver) return null;

      return (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 animate-fade-in-up">
              <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-zoom-in relative">
                  <div className="bg-slate-900 p-6 flex justify-between items-center text-white relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 rounded-full blur-2xl -mr-10 -mt-10"></div>
                      <h3 className="font-bold text-xl flex items-center gap-2 relative z-10">
                          <div className="bg-blue-600 p-2 rounded-lg"><Truck className="w-5 h-5" /></div>
                          Assign Gate
                      </h3>
                      <button onClick={closeAssignModal} className="hover:bg-white/10 p-2 rounded-full transition-colors relative z-10"><X className="w-5 h-5" /></button>
                  </div>
                  
                  <div className="p-6 space-y-6">
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xl">{driver.name.charAt(0)}</div>
                          <div>
                             <div className="font-bold text-slate-800 text-lg">{driver.name}</div>
                             <div className="text-slate-500 font-mono text-sm">{driver.licensePlate} • {driver.company}</div>
                          </div>
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Pilih Gate</label>
                          <div className="grid grid-cols-2 gap-4">
                              <button onClick={() => setSelectedGate(Gate.GATE_2)} className={`p-4 rounded-xl border-2 transition-all text-left ${selectedGate === Gate.GATE_2 ? 'border-blue-500 bg-blue-50' : 'border-slate-100 hover:border-slate-300'}`}>
                                  <div className={`font-bold text-lg mb-1 ${selectedGate === Gate.GATE_2 ? 'text-blue-700' : 'text-slate-700'}`}>GATE 2</div>
                                  <div className="text-xs text-slate-500">Antrian: {gate2Queue.length}</div>
                              </button>
                              <button onClick={() => setSelectedGate(Gate.GATE_4)} className={`p-4 rounded-xl border-2 transition-all text-left ${selectedGate === Gate.GATE_4 ? 'border-purple-500 bg-purple-50' : 'border-slate-100 hover:border-slate-300'}`}>
                                  <div className={`font-bold text-lg mb-1 ${selectedGate === Gate.GATE_4 ? 'text-purple-700' : 'text-slate-700'}`}>GATE 4</div>
                                  <div className="text-xs text-slate-500">Antrian: {gate4Queue.length}</div>
                              </button>
                          </div>
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Prioritas</label>
                          <div className="flex gap-3">
                              <button onClick={() => setSelectedPriority(Priority.NORMAL)} className={`flex-1 py-3 rounded-xl font-bold text-sm border-2 ${selectedPriority === Priority.NORMAL ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-500 border-slate-200'}`}>NORMAL</button>
                              <button onClick={() => setSelectedPriority(Priority.URGENT)} className={`flex-1 py-3 rounded-xl font-bold text-sm border-2 flex items-center justify-center gap-2 ${selectedPriority === Priority.URGENT ? 'bg-red-500 text-white border-red-500 shadow-red-200 shadow-lg' : 'bg-white text-slate-500 border-slate-200'}`}>URGENT <Activity className="w-4 h-4" /></button>
                          </div>
                      </div>
                  </div>

                  <div className="p-4 border-t border-slate-100 flex gap-3 bg-slate-50">
                      <button onClick={closeAssignModal} className="flex-1 py-3 text-slate-600 font-bold hover:bg-slate-200 rounded-xl transition-colors">Batal</button>
                      <button onClick={confirmAssign} className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg hover:-translate-y-0.5 transition-all">KONFIRMASI</button>
                  </div>
              </div>
          </div>
      );
  };

  return (
    <div className="h-screen flex flex-col bg-slate-50 overflow-hidden">
        <AssignModal />
        
        {/* TOP BAR: Fixed */}
        <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shrink-0 z-20 shadow-sm">
            <div className="flex items-center gap-4">
                 {onBack && (
                    <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors">
                        <ArrowLeft className="w-6 h-6" />
                    </button>
                )}
                <div>
                    <h1 className="text-xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                        OPERATIONAL DASHBOARD <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-bold tracking-wider border border-green-200">LIVE</span>
                    </h1>
                    <p className="text-xs text-slate-500 font-medium">
                        {time.toLocaleDateString('id-ID', {weekday:'long', day:'numeric', month:'long'})} • {time.toLocaleTimeString('id-ID')}
                    </p>
                </div>
            </div>
            
            <div className="flex items-center gap-4">
                {/* Search Bar - ALWAYS VISIBLE */}
                <div className="relative block w-64">
                    <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input 
                        type="text" 
                        placeholder="Cari Plat / Driver..." 
                        className="w-full pl-9 pr-4 py-2 rounded-lg bg-slate-100 border-none focus:ring-2 focus:ring-blue-500 text-sm font-medium"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                
                {/* Mini Stats */}
                <div className="flex gap-2">
                    <div className="px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-bold border border-blue-100">
                        In-Yard: {drivers.filter(d => d.status !== QueueStatus.COMPLETED && d.status !== QueueStatus.EXITED).length}
                    </div>
                    <div className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold border border-slate-200">
                        Total: {drivers.length}
                    </div>
                </div>
            </div>
        </div>

        {/* MAIN BOARD: Scrollable Columns Container */}
        <div className="flex-1 overflow-hidden p-6">
            {/* CHANGED: Always flex-row to ensure side-by-side columns */}
            <div className="flex flex-row gap-6 h-full items-start overflow-x-auto pb-2">
                
                {/* COLUMN 1: UNASSIGNED */}
                <div className="flex-1 h-full flex flex-col min-w-[400px] bg-slate-100/50 rounded-2xl border border-slate-200 overflow-hidden">
                    <div className="p-4 bg-white border-b border-slate-200 flex justify-between items-center shrink-0">
                        <div className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full bg-slate-400"></span>
                            <h2 className="font-bold text-slate-700 uppercase tracking-wide text-sm">New / Unassigned</h2>
                        </div>
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-md text-xs font-black">{unassigned.length}</span>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 custom-scrollbar">
                        <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                            {unassigned.length === 0 && (
                                <div className="col-span-full h-40 flex flex-col items-center justify-center text-slate-400 italic">
                                    <Truck className="w-8 h-8 mb-2 opacity-50" />
                                    <span className="text-sm">Tidak ada antrian baru</span>
                                </div>
                            )}
                            {unassigned.map(d => (
                                <DriverCard key={d.id} driver={d} onAssign={openAssignModal} onStatusChange={handleStatusChange} />
                            ))}
                        </div>
                    </div>
                </div>

                {/* COLUMN 2: GATE 2 */}
                <div className="flex-1 h-full flex flex-col min-w-[400px] bg-blue-50/50 rounded-2xl border border-blue-100 overflow-hidden shadow-sm">
                    <div className="p-4 bg-white/80 backdrop-blur-sm border-b border-blue-100 flex justify-between items-center shrink-0">
                        <div className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                            <h2 className="font-bold text-blue-800 uppercase tracking-wide text-sm">Gate 2 <span className="text-[10px] text-blue-400 font-normal ml-1">General Cargo</span></h2>
                        </div>
                        <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-md text-xs font-black">{gate2Queue.length}</span>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 custom-scrollbar">
                         <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                            {gate2Queue.length === 0 && (
                                <div className="col-span-full h-40 flex flex-col items-center justify-center text-blue-300 italic">
                                    <div className="w-10 h-10 border-2 border-blue-200 rounded-full flex items-center justify-center mb-2 font-bold">2</div>
                                    <span className="text-sm">Gate 2 Kosong</span>
                                </div>
                            )}
                            {gate2Queue.map(d => (
                                <DriverCard key={d.id} driver={d} onAssign={openAssignModal} onStatusChange={handleStatusChange} />
                            ))}
                         </div>
                    </div>
                </div>

                {/* COLUMN 3: GATE 4 */}
                <div className="flex-1 h-full flex flex-col min-w-[400px] bg-purple-50/50 rounded-2xl border border-purple-100 overflow-hidden shadow-sm">
                    <div className="p-4 bg-white/80 backdrop-blur-sm border-b border-purple-100 flex justify-between items-center shrink-0">
                         <div className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full bg-purple-500"></span>
                            <h2 className="font-bold text-purple-800 uppercase tracking-wide text-sm">Gate 4 <span className="text-[10px] text-purple-400 font-normal ml-1">Express</span></h2>
                        </div>
                        <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-md text-xs font-black">{gate4Queue.length}</span>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 custom-scrollbar">
                        <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                            {gate4Queue.length === 0 && (
                                <div className="col-span-full h-40 flex flex-col items-center justify-center text-purple-300 italic">
                                    <div className="w-10 h-10 border-2 border-purple-200 rounded-full flex items-center justify-center mb-2 font-bold">4</div>
                                    <span className="text-sm">Gate 4 Kosong</span>
                                </div>
                            )}
                            {gate4Queue.map(d => (
                                <DriverCard key={d.id} driver={d} onAssign={openAssignModal} onStatusChange={handleStatusChange} />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style>{`
            .custom-scrollbar::-webkit-scrollbar { width: 5px; }
            .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
            .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 10px; }
            .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.2); }
        `}</style>
    </div>
  );
};

export default AdminDashboard;
