
import React, { useState } from 'react';
import { Truck, User, Briefcase, CheckCircle, MapPin, Calendar, Lock, HelpCircle, X, Info, MessageCircle, FileText, AlertTriangle, Upload, FileCheck, RefreshCw, ArrowRight, ArrowLeft } from 'lucide-react';
import { createCheckIn } from '../services/dataService';
import { EntryType } from '../types';

interface Props {
  onSuccess: (driverId: string) => void;
  onBack?: () => void;
}

const ENTITIES = ['SBI', 'SDI', 'SRI', 'OTHER'];

// --- LOCATION CONFIGURATION ---
// Sociolla Whs Cikupa / Pergudangan Griya Idola Gudang Pink (Blok W1)
const TARGET_LAT = -6.226976;
const TARGET_LNG = 106.5446167;
const MAX_DISTANCE_METERS = 1000; // Radius 1KM untuk toleransi akurasi GPS & area gudang yang luas

const DriverCheckIn: React.FC<Props> = ({ onSuccess, onBack }) => {
  // Step 0: Mode Selection, 1: Form
  const [step, setStep] = useState(0); 
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [entryType, setEntryType] = useState<EntryType>(EntryType.WALK_IN);
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [showHelp, setShowHelp] = useState(false);
  
  // GPS State - Added 'warning' state
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'locating' | 'success' | 'warning' | 'error'>('idle');
  const [gpsErrorMsg, setGpsErrorMsg] = useState('');
  const [currentDistance, setCurrentDistance] = useState<number>(0);

  // Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [licensePlate, setLicensePlate] = useState('');
  const [entity, setEntity] = useState('SBI'); // Default
  const [pic, setPic] = useState('Bu Santi'); // Default for SBI
  
  // New PO State: Split into Year and Sequence OR Free Text
  const [poYear, setPoYear] = useState(new Date().getFullYear().toString());
  const [poSeq, setPoSeq] = useState('');
  const [poFreeText, setPoFreeText] = useState(''); // For OTHER entity
  const [poWarning, setPoWarning] = useState(''); // Smart Validation Warning
  
  // File Upload State
  const [docFile, setDocFile] = useState<File | null>(null);

  const [purpose, setPurpose] = useState<'LOADING' | 'UNLOADING'>('UNLOADING');

  // --- LOGIC: PIC & RESET ---
  const handleEntityChange = (newEntity: string) => {
      setEntity(newEntity);
      
      // Reset PO inputs and warnings when switching logic
      setPoSeq('');
      setPoFreeText('');
      setPoWarning('');
      setErrors({...errors, po: ''}); // Clear errors
      setPoYear(new Date().getFullYear().toString());

      // PIC Logic based on user requirement
      if (newEntity === 'SBI') {
          setPic('Bu Santi');
      } else if (newEntity === 'SDI') {
          setPic('Pak Azhari');
      } else {
          setPic('');
      }
  };

  // --- LOGIC: PO FORMATTING ---
  const getFormattedPO = () => {
      // Logic A: Entity OTHER (Fully Free Text)
      if (entity === 'OTHER') {
          // Tidak ada format PO/OTHER/... lagi. Murni input user.
          return poFreeText.trim() ? poFreeText.toUpperCase() : '-';
      }

      // Logic B: Standard Entities (Year + Seq)
      const safeSeq = poSeq ? poSeq : '...';
      return `PO/${entity}/${poYear}/${safeSeq}`;
  };

  const handleYearInput = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value.replace(/\D/g, '').slice(0, 4); // Max 4 digits
      setPoYear(val);
      if(errors.po) setErrors({...errors, po: ''});
  };

  const handleSeqInput = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value.replace(/\D/g, ''); // Only numbers
      setPoSeq(val);
      if(errors.po) setErrors({...errors, po: ''});
  };

  const handleFreeTextInput = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setPoFreeText(val);
      
      // Clear hard error when typing (will be re-checked on submit)
      if(errors.po) setErrors({...errors, po: ''});

      // --- SMART WARNING LOGIC (Soft Warning) ---
      const upperVal = val.toUpperCase();
      if (upperVal.includes('SBI')) {
          setPoWarning('Terdeteksi kode "SBI". Mohon ubah "Perusahaan Tujuan" di atas menjadi SBI.');
      } else if (upperVal.includes('SDI')) {
          setPoWarning('Terdeteksi kode "SDI". Mohon ubah "Perusahaan Tujuan" di atas menjadi SDI.');
      } else if (upperVal.includes('SRI')) {
          setPoWarning('Terdeteksi kode "SRI". Mohon ubah "Perusahaan Tujuan" di atas menjadi SRI.');
      } else {
          setPoWarning('');
      }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        setDocFile(e.target.files[0]);
        if(errors.doc) setErrors({...errors, doc: ''});
    }
  };

  // --- LOGIC: WHATSAPP SANITIZATION ---
  const handlePhoneInput = (e: React.ChangeEvent<HTMLInputElement>) => {
      let val = e.target.value.replace(/\D/g, ''); // Remove non-digits
      
      // Auto Prefix correction
      if (val.startsWith('0')) {
          val = '62' + val.substring(1);
      } else if (val.startsWith('8')) {
          val = '62' + val;
      }
      
      setPhone(val);
      if(errors.phone) setErrors({...errors, phone: ''});
  };

  const validate = () => {
    const newErrors: {[key: string]: string} = {};
    const plateRegex = /^[A-Z]{1,2}\s\d{1,4}\s[A-Z]{0,3}$/;
    if (!plateRegex.test(licensePlate.toUpperCase())) newErrors.licensePlate = 'Format plat salah (Contoh: B 1234 XYZ)';
    if (phone.length < 10) newErrors.phone = 'Nomor HP tidak valid';
    if (!name.trim()) newErrors.name = 'Nama wajib diisi';
    if (!pic.trim()) newErrors.pic = 'Nama PIC / Penerima wajib diisi';
    if (!docFile) newErrors.doc = 'Wajib upload foto Surat Jalan';
    
    // Validate PO based on Entity Type
    if (entity === 'OTHER') {
        const upperText = poFreeText.toUpperCase();
        if (!poFreeText.trim()) {
            newErrors.po = 'Dokumen / PO wajib diisi';
        } 
        // --- HARD BLOCK LOGIC ---
        else if (upperText.includes('SBI') || upperText.includes('SDI') || upperText.includes('SRI')) {
             newErrors.po = 'DILARANG: Terdeteksi kode internal (SBI/SDI/SRI). Mohon ganti "Perusahaan Tujuan" di atas.';
        }
    } else {
        if (poYear.length !== 4) newErrors.po = 'Tahun harus 4 digit';
        if (!poSeq.trim()) newErrors.po = 'Nomor Urut PO wajib diisi';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // --- LOCATION CALCULATION (Haversine Formula) ---
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // metres
    const φ1 = lat1 * Math.PI/180; // φ, λ in radians
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    const d = R * c; // in metres
    return d;
  };

  const handleModeSelect = (type: EntryType) => {
      setEntryType(type);
      
      if (type === EntryType.BOOKING) {
          // Booking does not require GPS check at this stage (usually checked upon arrival)
          setStep(1);
      } else {
          // Walk-In REQUIRES GPS check FIRST
          checkLocation();
      }
  };

  const checkLocation = () => {
    setGpsStatus('locating');
    
    if (!navigator.geolocation) {
        setGpsStatus('error');
        setGpsErrorMsg('Browser Anda tidak mendukung Geolocation.');
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            const distance = calculateDistance(latitude, longitude, TARGET_LAT, TARGET_LNG);
            setCurrentDistance(distance);

            if (distance <= MAX_DISTANCE_METERS) {
                setGpsStatus('success');
                // Auto proceed after short delay
                setTimeout(() => {
                    setGpsStatus('idle'); // Hide overlay
                    setStep(1); // Open Form
                }, 1500);
            } else {
                // MODIFICATION: Instead of Error/Block, use Warning but allow proceed
                setGpsStatus('warning');
            }
        },
        (error) => {
            setGpsStatus('error');
            let msg = 'Gagal mengambil lokasi.';
            if (error.code === 1) msg = 'Izin lokasi ditolak. Mohon aktifkan GPS.';
            else if (error.code === 2) msg = 'Sinyal GPS tidak tersedia.';
            else if (error.code === 3) msg = 'Timeout saat mencari lokasi.';
            setGpsErrorMsg(msg);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const proceedAnyway = () => {
      setGpsStatus('idle');
      setStep(1);
  }

  const submitData = () => {
      // Simulate API Call
      setTimeout(() => {
        const newDriver = createCheckIn({
            name,
            phone, // Already sanitized to 62...
            licensePlate: licensePlate.toUpperCase(),
            company: entity,
            pic,
            purpose,
            doNumber: getFormattedPO(),
            entryType: entryType,
            documentFile: docFile ? docFile.name : undefined
        });
        setIsSubmitting(false);
        onSuccess(newDriver.id);
      }, 1000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
        return;
    }
    setIsSubmitting(true);
    // Directly submit because GPS was already checked at the beginning for Walk-In
    submitData();
  };

  // --- HELP MODAL COMPONENT ---
  const HelpModal = () => {
      if (!showHelp) return null;
      return (
          <div className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in-up">
              <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl">
                  <div className="bg-slate-100 p-4 flex justify-between items-center border-b border-slate-200">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2">
                          <HelpCircle className="w-5 h-5 text-blue-600" /> Panduan Pengisian
                      </h3>
                      <button onClick={() => setShowHelp(false)} className="p-1 hover:bg-slate-200 rounded-full"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="p-6 space-y-4">
                      <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-xl">
                          <h4 className="font-bold text-blue-700 text-sm mb-1 flex items-center gap-2"><FileText className="w-4 h-4"/> Format PO</h4>
                          <p className="text-xs text-blue-600">
                              <strong>SBI/SDI/SRI:</strong> Pisah Tahun & Angka (Otomatis Format).<br/>
                              <strong>OTHER:</strong> Bebas ketik manual apa saja (Surat Jalan / Note).
                          </p>
                      </div>

                      <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded-r-xl">
                          <h4 className="font-bold text-purple-700 text-sm mb-1 flex items-center gap-2"><User className="w-4 h-4"/> PIC / Penerima</h4>
                          <p className="text-xs text-purple-600">
                              Jika pilih <strong>SBI</strong>, PIC otomatis <strong>"Bu Santi"</strong>.<br/>
                              Jika pilih <strong>SDI</strong>, PIC otomatis <strong>"Pak Azhari"</strong>.
                          </p>
                      </div>

                      <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded-r-xl">
                          <h4 className="font-bold text-orange-700 text-sm mb-1 flex items-center gap-2"><Upload className="w-4 h-4"/> Upload Surat Jalan</h4>
                          <p className="text-xs text-orange-600">
                              Wajib melampirkan foto Surat Jalan / DO. Bisa format Gambar atau PDF.
                          </p>
                      </div>
                  </div>
                  <button onClick={() => setShowHelp(false)} className="w-full py-4 bg-slate-900 text-white font-bold hover:bg-slate-800 transition-colors">
                      SAYA MENGERTI
                  </button>
              </div>
          </div>
      );
  }

  // --- VIEW: GPS LOADING / STATUS OVERLAY ---
  if (gpsStatus !== 'idle') {
      return (
          <div className="fixed inset-0 z-50 bg-slate-900/90 backdrop-blur-md flex flex-col items-center justify-center p-6 animate-fade-in-up">
              <div className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl relative overflow-hidden">
                  
                  {/* Decor */}
                  <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 to-purple-500"></div>

                  {gpsStatus === 'locating' && (
                      <>
                        <div className="relative mx-auto mb-6 w-20 h-20">
                            <span className="absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-25 animate-ping"></span>
                            <div className="relative inline-flex rounded-full h-20 w-20 bg-blue-100 items-center justify-center border-4 border-white shadow-lg">
                                <MapPin className="w-10 h-10 text-blue-600 animate-bounce" />
                            </div>
                        </div>
                        <h3 className="text-xl font-black text-slate-800 mb-2">Memeriksa Lokasi</h3>
                        <p className="text-slate-500 text-sm">Mohon tunggu, sistem sedang memverifikasi posisi Anda di area Gudang Sociolla Cikupa.</p>
                      </>
                  )}

                  {gpsStatus === 'success' && (
                      <>
                        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-zoom-in border-4 border-white shadow-lg">
                            <CheckCircle className="w-10 h-10" />
                        </div>
                        <h3 className="text-xl font-black text-slate-800 mb-2">Lokasi Sesuai!</h3>
                        <p className="text-slate-500 text-sm">Jarak: {Math.round(currentDistance)} meter.</p>
                        <p className="text-green-600 font-bold mt-2 text-sm">Membuka Formulir...</p>
                      </>
                  )}

                  {/* WARNING STATUS: Driver is FAR but ALLOWED to proceed */}
                  {gpsStatus === 'warning' && (
                      <>
                         <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse border-4 border-white shadow-lg">
                            <AlertTriangle className="w-10 h-10" />
                        </div>
                        <h3 className="text-xl font-black text-amber-600 mb-2">Lokasi Jauh Terdeteksi</h3>
                        <div className="bg-amber-50 border border-amber-100 p-3 rounded-xl mb-6">
                            <p className="text-slate-600 text-sm font-medium">
                                Anda terdeteksi berjarak <strong>{Math.round(currentDistance)} meter</strong> dari titik gudang.
                            </p>
                        </div>
                        <p className="text-xs text-slate-400 mb-6 font-medium">
                            Pastikan Anda benar-benar menuju ke Sociolla Cikupa (Griya Idola Blok W1).
                        </p>
                        <button 
                            onClick={proceedAnyway}
                            className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold shadow-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 mb-3"
                        >
                            Tetap Lanjut Isi Form <ArrowRight className="w-4 h-4"/>
                        </button>
                         <button 
                            onClick={() => { setGpsStatus('idle'); setEntryType(EntryType.WALK_IN); }}
                            className="w-full py-3 text-slate-500 font-bold hover:text-slate-800 transition-colors"
                        >
                            Batal
                        </button>
                      </>
                  )}

                  {gpsStatus === 'error' && (
                      <>
                        <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-shake border-4 border-white shadow-lg">
                            <Lock className="w-10 h-10" />
                        </div>
                        <h3 className="text-xl font-black text-slate-800 mb-2">GPS Error</h3>
                        <div className="bg-red-50 border border-red-100 p-3 rounded-xl mb-6">
                            <p className="text-red-600 font-bold text-sm leading-relaxed">{gpsErrorMsg}</p>
                        </div>
                        <div className="flex flex-col gap-3">
                            <button 
                                onClick={checkLocation} 
                                className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-200 hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                            >
                                <RefreshCw className="w-4 h-4" /> Coba Lagi
                            </button>
                            <button 
                                onClick={() => { setGpsStatus('idle'); setEntryType(EntryType.WALK_IN); }}
                                className="w-full py-3 bg-white border-2 border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                            >
                                Batalkan
                            </button>
                        </div>
                      </>
                  )}
              </div>
          </div>
      );
  }

  // --- VIEW: STEP 0 (MODE SELECT) ---
  if (step === 0) {
      return (
        <div className="max-w-xl mx-auto animate-fade-in-up pb-20 pt-10">
            {onBack && (
                <button 
                    onClick={onBack}
                    className="mb-6 flex items-center gap-2 text-slate-500 font-bold hover:text-blue-600 transition-colors"
                >
                    <ArrowLeft className="w-5 h-5" /> Kembali ke Menu
                </button>
            )}
            <h2 className="text-3xl font-black text-center text-slate-800 mb-8">Pilih Jenis Kedatangan</h2>
            
            <div className="grid gap-6">
                <button 
                    onClick={() => handleModeSelect(EntryType.WALK_IN)}
                    className="group relative overflow-hidden bg-gradient-to-br from-blue-600 to-blue-700 text-white p-8 rounded-3xl shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all text-left"
                >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
                    <MapPin className="w-12 h-12 mb-4 text-blue-200" />
                    <h3 className="text-2xl font-bold mb-2">Saya Sudah Sampai</h3>
                    <p className="text-blue-100 opacity-90 mb-4">Daftar antrian sekarang (Walk-In).</p>
                    
                    <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl border border-white/10 text-xs font-medium flex items-start gap-2">
                        <Info className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>Sistem akan memeriksa lokasi GPS Anda untuk verifikasi kedatangan.</span>
                    </div>
                </button>

                <button 
                    onClick={() => handleModeSelect(EntryType.BOOKING)}
                    className="group relative overflow-hidden bg-white border-2 border-slate-100 p-8 rounded-3xl shadow-lg hover:border-purple-500 hover:shadow-purple-500/10 transition-all text-left"
                >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full -mr-10 -mt-10 blur-xl"></div>
                    <Calendar className="w-12 h-12 mb-4 text-purple-600" />
                    <h3 className="text-2xl font-bold text-slate-800 mb-2">Booking Jadwal</h3>
                    <p className="text-slate-500">Reservasi kedatangan untuk besok atau jam tertentu.</p>
                </button>
            </div>
        </div>
      );
  }

  // --- VIEW: STEP 1 (FORM INPUT) ---
  return (
    <div className="max-w-xl mx-auto animate-fade-in-up pb-20">
      
      <HelpModal />

      <div className="flex justify-between items-center mb-4">
        <button onClick={() => setStep(0)} className="text-sm font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" /> Kembali
        </button>
      </div>

      {/* Header Card */}
      <div className={`rounded-3xl p-8 text-white shadow-2xl mb-8 relative overflow-hidden ${entryType === EntryType.BOOKING ? 'bg-gradient-to-r from-purple-600 to-pink-600' : 'bg-gradient-to-r from-blue-600 to-indigo-600'}`}>
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
        <button onClick={() => setShowHelp(true)} className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 p-2 rounded-full backdrop-blur-md transition-all">
            <HelpCircle className="w-6 h-6 text-white" />
        </button>
        <h2 className="text-3xl font-black mb-2 flex items-center gap-3">
          {entryType === EntryType.BOOKING ? <Calendar className="w-8 h-8"/> : <MapPin className="w-8 h-8" />}
          {entryType === EntryType.BOOKING ? 'Form Booking' : 'Check-in Lokasi'}
        </h2>
        <p className="text-white/90 font-medium text-lg opacity-90">
            Pastikan data Anda sesuai surat jalan.
        </p>
      </div>

      {/* Main Form Card */}
      <form onSubmit={handleSubmit} className="glass-card rounded-3xl p-6 md:p-8 space-y-8 relative">
        
        {/* Section 1: Identitas */}
        <div className="space-y-5">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-200">
            <span className="bg-blue-100 text-blue-600 p-1.5 rounded-lg"><User className="w-5 h-5" /></span> 
            Identitas Driver
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="group">
              <label className="block text-sm font-bold text-slate-600 mb-2 ml-1">Nama Lengkap*</label>
              <input
                type="text"
                className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-slate-100 focus:border-blue-500 focus:bg-white transition-all outline-none font-medium ${errors.name ? 'border-red-500' : ''}`}
                placeholder="Nama Sesuai KTP"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            
            <div className="group">
              <label className="block text-sm font-bold text-slate-600 mb-2 ml-1">WhatsApp*</label>
              <div className="relative">
                  <div className="absolute left-0 top-0 bottom-0 px-3 bg-slate-100 border-2 border-r-0 border-slate-100 rounded-l-xl flex items-center font-bold text-slate-500">
                      +62
                  </div>
                  <input
                    type="tel"
                    className={`w-full pl-14 pr-4 py-3 rounded-xl bg-slate-50 border-2 border-slate-100 focus:border-blue-500 focus:bg-white transition-all outline-none font-medium ${errors.phone ? 'border-red-500' : ''}`}
                    placeholder="8123456789"
                    value={phone.replace(/^62/, '')}
                    onChange={handlePhoneInput}
                  />
              </div>
              <p className="text-[10px] text-slate-400 mt-1 ml-1">Cukup ketik angka (08... atau 8...)</p>
            </div>
          </div>

          <div className="group">
              <label className="block text-sm font-bold text-slate-600 mb-2 ml-1">No. Polisi*</label>
              <input
                type="text"
                className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-slate-100 focus:border-blue-500 focus:bg-white transition-all outline-none font-black text-xl uppercase tracking-wider ${errors.licensePlate ? 'border-red-500' : ''}`}
                placeholder="B 1234 XYZ"
                value={licensePlate}
                onChange={(e) => setLicensePlate(e.target.value)}
              />
           </div>
        </div>

        {/* Section 2: Tujuan & PIC */}
        <div className="space-y-5">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-200">
             <span className="bg-indigo-100 text-indigo-600 p-1.5 rounded-lg"><Briefcase className="w-5 h-5" /></span>
             Tujuan & PIC
          </h3>

          <div className="group">
              <label className="block text-sm font-bold text-slate-600 mb-3 ml-1">Perusahaan Tujuan (Entity)*</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {ENTITIES.map(ent => (
                      <button
                        type="button"
                        key={ent}
                        onClick={() => handleEntityChange(ent)}
                        className={`py-3 rounded-xl font-bold border-2 transition-all ${entity === ent ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-white border-slate-100 text-slate-500 hover:border-slate-300'}`}
                      >
                          {ent}
                      </button>
                  ))}
              </div>
          </div>
          
          <div className="group">
              <label className="block text-sm font-bold text-slate-600 mb-2 ml-1">PIC / Penerima*</label>
              <div className="relative">
                  <input
                    type="text"
                    disabled={entity === 'SBI' || entity === 'SDI'}
                    className={`w-full px-4 py-3 rounded-xl border-2 border-slate-100 transition-all outline-none font-medium ${
                        (entity === 'SBI' || entity === 'SDI') 
                        ? 'bg-slate-200 text-slate-500 cursor-not-allowed' 
                        : 'bg-white focus:border-indigo-500'
                    } ${errors.pic ? 'border-red-500' : ''}`}
                    placeholder="Nama Penerima"
                    value={pic}
                    onChange={(e) => setPic(e.target.value)}
                  />
                  {(entity === 'SBI' || entity === 'SDI') && (
                      <Lock className="absolute right-4 top-3.5 w-5 h-5 text-slate-400" />
                  )}
              </div>
              <p className="text-[10px] text-slate-400 mt-1 ml-1">
                  {(entity === 'SBI') && "Nama PIC otomatis terisi untuk SBI (Bu Santi)."}
                  {(entity === 'SDI') && "Nama PIC otomatis terisi untuk SDI (Pak Azhari)."}
                  {(entity !== 'SBI' && entity !== 'SDI') && "Silakan isi nama penerima manual."}
              </p>
          </div>
        </div>

        {/* Section 3: Detail Muatan & PO */}
        <div className="space-y-5">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 pb-2 border-b border-slate-200">
            <span className="bg-purple-100 text-purple-600 p-1.5 rounded-lg"><Truck className="w-5 h-5" /></span>
            Detail Muatan & PO
          </h3>
          
          <div className="bg-slate-50 p-4 rounded-xl border-2 border-slate-100">
            <label className="block text-sm font-bold text-slate-600 mb-3 ml-1">Keperluan*</label>
            <div className="grid grid-cols-2 gap-4">
              <label className="cursor-pointer group relative">
                <input type="radio" name="purpose" value="UNLOADING" checked={purpose === 'UNLOADING'} onChange={() => setPurpose('UNLOADING')} className="peer sr-only" />
                <div className="p-4 rounded-xl bg-white border-2 border-slate-200 text-center transition-all peer-checked:border-purple-600 peer-checked:bg-purple-50 peer-checked:text-purple-700">
                   <div className="font-bold">UNLOADING</div>
                </div>
              </label>
              <label className="cursor-pointer group relative">
                <input type="radio" name="purpose" value="LOADING" checked={purpose === 'LOADING'} onChange={() => setPurpose('LOADING')} className="peer sr-only" />
                 <div className="p-4 rounded-xl bg-white border-2 border-slate-200 text-center transition-all peer-checked:border-blue-600 peer-checked:bg-blue-50 peer-checked:text-blue-700">
                   <div className="font-bold">LOADING</div>
                </div>
              </label>
            </div>
          </div>

          <div className="group">
            <label className="block text-sm font-bold text-slate-600 mb-2 ml-1">
                {entity === 'OTHER' ? 'Nomor Dokumen / Catatan*' : 'Nomor PO*'}
            </label>
            
            {/* CONDITIONAL PO INPUT */}
            {entity === 'OTHER' ? (
                 <div className="space-y-2">
                     <input
                      type="text"
                      className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-slate-100 focus:border-purple-500 focus:bg-white transition-all outline-none font-bold text-lg uppercase ${errors.po ? 'border-red-500 bg-red-50' : ''}`}
                      placeholder="Ketik Bebas (Contoh: SJ-2025-X atau Note)"
                      value={poFreeText}
                      onChange={handleFreeTextInput}
                    />
                    
                    {/* Error Message */}
                    {errors.po && (
                        <div className="flex items-center gap-2 text-red-500 text-sm font-bold bg-red-100 border border-red-200 p-3 rounded-lg animate-shake">
                            <AlertTriangle className="w-5 h-5 shrink-0" />
                            {errors.po}
                        </div>
                    )}

                    {/* SMART VALIDATION WARNING (Soft) - only show if no hard error */}
                    {!errors.po && poWarning && (
                        <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 text-amber-700 p-3 rounded-lg animate-fade-in-up">
                            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                            <p className="text-sm font-semibold">{poWarning}</p>
                        </div>
                    )}
                 </div>
            ) : (
                <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-1">
                        <div className="text-xs font-bold text-slate-400 mb-1 ml-1">Tahun (4 Digit)</div>
                        <input
                          type="tel"
                          maxLength={4}
                          className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-slate-100 focus:border-purple-500 focus:bg-white transition-all outline-none font-black text-lg text-center ${errors.po ? 'border-red-500' : ''}`}
                          placeholder="YYYY"
                          value={poYear}
                          onChange={handleYearInput}
                        />
                    </div>
                    <div className="col-span-2">
                        <div className="text-xs font-bold text-slate-400 mb-1 ml-1">Nomor Urut</div>
                        <input
                          type="tel"
                          className={`w-full px-4 py-3 rounded-xl bg-slate-50 border-2 border-slate-100 focus:border-purple-500 focus:bg-white transition-all outline-none font-black text-lg tracking-widest ${errors.po ? 'border-red-500' : ''}`}
                          placeholder="Contoh: 0001"
                          value={poSeq}
                          onChange={handleSeqInput}
                        />
                    </div>
                </div>
            )}

            {/* Live Preview Box */}
            <div className="mt-3 bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
                <div>
                    <p className="text-xs font-bold text-blue-500 uppercase">
                         {entity === 'OTHER' ? 'Preview Data:' : 'Hasil Format System:'}
                    </p>
                    <p className="text-lg font-black text-blue-800 font-mono tracking-tight">{getFormattedPO()}</p>
                </div>
            </div>
          </div>

          {/* NEW FILE UPLOAD SECTION */}
          <div className="group">
             <label className="block text-sm font-bold text-slate-600 mb-2 ml-1">Upload Surat Jalan / DO*</label>
             <div className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${docFile ? 'border-green-500 bg-green-50' : (errors.doc ? 'border-red-500 bg-red-50' : 'border-slate-300 hover:border-purple-500 hover:bg-slate-50')}`}>
                <input 
                    type="file" 
                    id="docUpload" 
                    className="hidden" 
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                />
                
                {!docFile ? (
                    <label htmlFor="docUpload" className="cursor-pointer flex flex-col items-center justify-center gap-2">
                        <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                            <Upload className="w-6 h-6" />
                        </div>
                        <p className="font-bold text-slate-600">Klik untuk upload foto</p>
                        <p className="text-xs text-slate-400">Format: JPG, PNG, PDF</p>
                    </label>
                ) : (
                    <div className="flex flex-col items-center justify-center gap-2">
                        <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 animate-zoom-in">
                            <FileCheck className="w-6 h-6" />
                        </div>
                        <p className="font-bold text-green-700">{docFile.name}</p>
                        <label htmlFor="docUpload" className="text-xs font-bold text-slate-500 underline cursor-pointer hover:text-purple-600">
                            Ganti File
                        </label>
                    </div>
                )}
             </div>
             {errors.doc && <p className="text-red-500 text-xs font-bold mt-1 ml-1">{errors.doc}</p>}
          </div>

        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-4 rounded-xl font-bold text-lg text-white shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all disabled:opacity-70 disabled:cursor-not-allowed overflow-hidden relative bg-slate-900"
        >
            {isSubmitting ? 'Memproses...' : (entryType === EntryType.WALK_IN ? 'SUBMIT CHECK-IN' : 'SUBMIT BOOKING')}
        </button>

      </form>
    </div>
  );
};

export default DriverCheckIn;
