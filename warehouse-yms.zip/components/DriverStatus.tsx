
import React, { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Clock, MapPin, RefreshCw, Truck, Calendar, FileText, CheckCircle, ArrowLeft } from 'lucide-react';
import { DriverData, QueueStatus, Gate } from '../types';
import { getDriverById, getDrivers } from '../services/dataService';

interface Props {
  driverId: string;
  onBack?: () => void;
}

const DriverStatus: React.FC<Props> = ({ driverId, onBack }) => {
  const [driver, setDriver] = useState<DriverData | null>(null);
  const [position, setPosition] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  const fetchStatus = () => {
    const data = getDriverById(driverId);
    if (data) {
      setDriver(data);
      if (data.status === QueueStatus.WAITING && data.gate !== Gate.NONE) {
        const allDrivers = getDrivers();
        const ahead = allDrivers.filter(d => 
          d.gate === data.gate && 
          d.status === QueueStatus.WAITING && 
          d.checkInTime < data.checkInTime
        );
        setPosition(ahead.length + 1);
      } else {
        setPosition(0);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, [driverId]);

  if (loading) return <div className="min-h-[50vh] flex items-center justify-center"><div className="animate-spin w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full"></div></div>;
  if (!driver) return <div className="p-8 text-center text-red-600 font-bold bg-white rounded-xl shadow-lg mt-10">Data antrian tidak ditemukan.</div>;

  const getStatusStyle = (status: QueueStatus) => {
    switch (status) {
      case QueueStatus.UNASSIGNED: 
        return {
           bg: 'bg-gradient-to-br from-orange-400 to-amber-500', 
           icon: '⏳', 
           label: 'Menunggu Gate',
           desc: 'Mohon tunggu, admin sedang menentukan gate.',
           animate: ''
        };
      case QueueStatus.WAITING: 
        return {
           bg: 'bg-gradient-to-br from-yellow-400 to-orange-500', 
           icon: '🚶', 
           label: 'Dalam Antrian',
           desc: 'Silakan parkir dan tunggu panggilan.',
           animate: ''
        };
      case QueueStatus.CALLED: 
        return {
           bg: 'bg-gradient-to-br from-blue-600 to-indigo-600', 
           icon: '📢', 
           label: 'SILAKAN MERAPAT!',
           desc: 'Segera menuju loading dock sekarang!',
           animate: 'animate-pulse-slow'
        };
      case QueueStatus.LOADING: 
        return {
           bg: 'bg-gradient-to-br from-emerald-500 to-teal-500', 
           icon: '🔄', 
           label: 'Sedang Loading',
           desc: 'Proses bongkar muat sedang berlangsung.',
           animate: 'animate-pulse'
        };
      case QueueStatus.COMPLETED: 
        return {
           bg: 'bg-gradient-to-br from-slate-700 to-slate-900', 
           icon: '✅', 
           label: 'Selesai',
           desc: 'Terima kasih, hati-hati di jalan.',
           animate: ''
        };
      case QueueStatus.CANCELLED: 
        return {
           bg: 'bg-gradient-to-br from-red-500 to-rose-600', 
           icon: '❌', 
           label: 'Dibatalkan',
           desc: 'Antrian ini telah dibatalkan.',
           animate: ''
        };
      default: return { bg: 'bg-gray-500', icon: '?', label: status, desc: '', animate: '' };
    }
  };

  const statusStyle = getStatusStyle(driver.status);

  return (
    <div className="max-w-md mx-auto animate-fade-in-up pb-10">
      
      {onBack && (
        <button 
            onClick={onBack}
            className="mb-6 flex items-center gap-2 text-slate-500 font-bold hover:text-blue-600 transition-colors"
        >
            <ArrowLeft className="w-5 h-5" /> Kembali
        </button>
      )}

      {/* Main Status Card */}
      <div className={`rounded-3xl shadow-2xl overflow-hidden text-white relative ${statusStyle.animate} transition-all duration-500`}>
        <div className={`absolute inset-0 ${statusStyle.bg}`}></div>
        
        {/* Background Patterns */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-black/10 rounded-full blur-3xl -ml-10 -mb-10"></div>
        
        <div className="relative p-8 text-center z-10">
            <div className="text-6xl mb-4 filter drop-shadow-md">{statusStyle.icon}</div>
            <h1 className="text-3xl font-black uppercase tracking-wide mb-2 drop-shadow-sm">{statusStyle.label}</h1>
            <p className="text-white/90 font-medium text-lg leading-relaxed">{statusStyle.desc}</p>
            
            {driver.status === QueueStatus.WAITING && (
               <div className="mt-6 inline-block bg-white/20 backdrop-blur-md px-6 py-2 rounded-full border border-white/30">
                  <span className="font-bold text-xl">Antrian ke-{position}</span>
               </div>
            )}
        </div>

        {/* Gate Info Strip */}
        {driver.gate !== Gate.NONE && (
           <div className="bg-black/20 backdrop-blur-sm p-4 flex items-center justify-between border-t border-white/10">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-white/20 rounded-lg"><MapPin className="w-5 h-5 text-white" /></div>
                 <div className="text-left">
                    <p className="text-xs text-white/70 uppercase font-bold tracking-wider">Lokasi Gate</p>
                    <p className="text-xl font-bold">{driver.gate.replace('_', ' ')}</p>
                 </div>
              </div>
              <div className="text-right">
                 <p className="text-xs text-white/70 uppercase font-bold tracking-wider">Nomor</p>
                 <p className="text-4xl font-black font-mono tracking-tighter">{driver.queueNumber}</p>
              </div>
           </div>
        )}
      </div>

      {/* Details Card */}
      <div className="glass-card mt-6 rounded-3xl p-6 shadow-xl relative overflow-hidden">
         <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-purple-500"></div>
         
         <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <div>
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Driver</p>
               <h3 className="font-bold text-xl text-slate-800">{driver.name}</h3>
            </div>
            <div className="text-right">
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Plat Nomor</p>
               <div className="bg-slate-100 px-3 py-1 rounded-lg font-mono font-bold text-slate-700 border border-slate-200">
                  {driver.licensePlate}
               </div>
            </div>
         </div>

         <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-colors">
               <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                  <Truck className="w-5 h-5" />
               </div>
               <div>
                  <p className="text-xs text-slate-500 font-semibold">Ekspedisi</p>
                  <p className="font-bold text-slate-800">{driver.company}</p>
               </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-colors">
               <div className="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                  <FileText className="w-5 h-5" />
               </div>
               <div>
                  <p className="text-xs text-slate-500 font-semibold">Dokumen / DO</p>
                  <p className="font-bold text-slate-800">{driver.doNumber}</p>
                  {driver.documentFile && (
                      <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded font-bold flex items-center gap-1 mt-1 w-fit">
                          <CheckCircle className="w-3 h-3" /> Terlampir
                      </span>
                  )}
               </div>
            </div>

            <div className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl transition-colors">
               <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center text-orange-600">
                  <Clock className="w-5 h-5" />
               </div>
               <div>
                  <p className="text-xs text-slate-500 font-semibold">Waktu Check-in</p>
                  <p className="font-bold text-slate-800">
                     {new Date(driver.checkInTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                  </p>
               </div>
            </div>
         </div>

         {/* QR Code Section */}
         <div className="mt-8 pt-6 border-t border-dashed border-slate-200 text-center">
            <div className="bg-white p-3 rounded-2xl shadow-sm border inline-block mb-3">
               <QRCodeSVG value={`https://yms-app.com/status/${driverId}`} size={100} />
            </div>
            <p className="text-xs font-medium text-slate-400">Scan untuk simpan status</p>
         </div>
      </div>
      
      <div className="flex flex-col gap-3 mt-6">
        <button 
            onClick={fetchStatus}
            className="w-full flex items-center justify-center gap-2 bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-colors py-3 rounded-xl"
        >
            <RefreshCw className="w-4 h-4" /> Refresh Data
        </button>

        {onBack && (
             <button 
                onClick={onBack}
                className="w-full flex items-center justify-center gap-2 text-slate-400 font-bold hover:text-slate-600 transition-colors py-2"
            >
                Kembali ke Menu Utama
            </button>
        )}
      </div>

    </div>
  );
};

export default DriverStatus;
