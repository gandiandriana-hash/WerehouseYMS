
import React, { useState, useEffect } from 'react';
import { getDrivers, securityCheckIn, updateStatus } from '../services/dataService';
import { DriverData, QueueStatus } from '../types';
import { Search, LogIn, LogOut, ShieldCheck, User, Truck, FileText, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';

interface Props {
  onBack?: () => void;
}

const SecurityDashboard: React.FC<Props> = ({ onBack }) => {
  const [drivers, setDrivers] = useState<DriverData[]>([]);
  const [activeTab, setActiveTab] = useState<'IN' | 'OUT'>('IN');
  const [search, setSearch] = useState('');

  const refresh = () => setDrivers(getDrivers());

  useEffect(() => {
      refresh();
      const interval = setInterval(refresh, 5000);
      return () => clearInterval(interval);
  }, []);

  const handleGateIn = (id: string) => {
      if (confirm('Izinkan kendaraan masuk?')) {
          securityCheckIn(id);
          refresh();
      }
  };

  const handleGateOut = (id: string) => {
      if (confirm('Konfirmasi kendaraan keluar?')) {
          updateStatus(id, QueueStatus.EXITED);
          refresh();
      }
  };

  // Filter Logic
  const filteredList = drivers.filter(d => {
      const matchSearch = d.licensePlate.includes(search.toUpperCase()) || d.name.toLowerCase().includes(search.toLowerCase());
      
      if (activeTab === 'IN') {
          // Show BOOKED or UNASSIGNED (Walk-in) that haven't entered yet
          // Simple logic: if status is BOOKED or UNASSIGNED or even ASSIGNED but no securityInTime?
          // Let's stick to: Booking or Unassigned or Waiting (if assigned remotely)
          const validStatus = [QueueStatus.BOOKED, QueueStatus.UNASSIGNED, QueueStatus.WAITING];
          return matchSearch && validStatus.includes(d.status) && !d.securityInTime;
      } else {
          // Show COMPLETED (Done loading, ready to exit)
          return matchSearch && d.status === QueueStatus.COMPLETED;
      }
  });

  const Card: React.FC<{ data: DriverData }> = ({ data }) => (
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
              <div className={`w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold ${activeTab === 'IN' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                  {data.licensePlate.split(' ')[0]}
              </div>
              <div>
                  <h3 className="text-xl font-black text-slate-800">{data.licensePlate}</h3>
                  <div className="flex flex-col text-sm text-slate-500 font-medium mt-1">
                      <span className="flex items-center gap-1"><User className="w-3 h-3" /> {data.name}</span>
                      <span className="flex items-center gap-1"><Truck className="w-3 h-3" /> {data.company}</span>
                      <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> {data.doNumber}</span>
                  </div>
              </div>
          </div>
          
          <button 
            onClick={() => activeTab === 'IN' ? handleGateIn(data.id) : handleGateOut(data.id)}
            className={`px-6 py-4 rounded-xl font-bold text-lg shadow-lg transition-transform hover:scale-105 active:scale-95 flex items-center gap-2 ${activeTab === 'IN' ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-slate-800 text-white hover:bg-slate-900'}`}
          >
              {activeTab === 'IN' ? <><LogIn /> GATE IN</> : <><LogOut /> GATE OUT</>}
          </button>
      </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
        {/* Security Header */}
        <div className="bg-slate-900 text-white p-6 shadow-xl sticky top-0 z-20">
            <div className="max-w-4xl mx-auto flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <ShieldCheck className="w-8 h-8 text-green-400" />
                    <div>
                        <h1 className="text-xl font-black tracking-wide">POS KEAMANAN</h1>
                        <p className="text-slate-400 text-xs font-bold tracking-wider">GATE CONTROL</p>
                    </div>
                </div>
                <div className="flex items-center gap-6">
                    <div className="text-right hidden sm:block">
                        <p className="text-2xl font-mono font-bold">{new Date().toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit'})}</p>
                    </div>
                    {onBack && (
                        <button 
                            onClick={onBack}
                            className="bg-slate-800 hover:bg-slate-700 border border-slate-700 p-2 px-4 rounded-lg text-white transition-colors flex items-center gap-2"
                            title="Kembali ke Menu"
                        >
                            <ArrowLeft className="w-5 h-5" />
                            <span className="hidden sm:inline font-bold text-sm">Portal</span>
                        </button>
                    )}
                </div>
            </div>
        </div>

        <div className="max-w-4xl mx-auto p-4 space-y-6 mt-4">
            {/* Tabs */}
            <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-slate-200">
                <button 
                    onClick={() => setActiveTab('IN')}
                    className={`flex-1 py-4 rounded-xl font-black text-lg flex items-center justify-center gap-2 transition-all ${activeTab === 'IN' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
                >
                    <LogIn /> MASUK (CHECK-IN)
                </button>
                <button 
                    onClick={() => setActiveTab('OUT')}
                    className={`flex-1 py-4 rounded-xl font-black text-lg flex items-center justify-center gap-2 transition-all ${activeTab === 'OUT' ? 'bg-slate-800 text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
                >
                    <LogOut /> KELUAR (CHECK-OUT)
                </button>
            </div>

            {/* Search */}
            <div className="relative">
                <Search className="absolute left-4 top-4 text-slate-400 w-6 h-6" />
                <input 
                    type="text" 
                    placeholder="Ketik Nopol atau Nama Supir..." 
                    className="w-full pl-14 pr-4 py-4 rounded-xl border-2 border-slate-200 focus:border-blue-500 focus:outline-none text-lg font-bold shadow-sm"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            {/* List */}
            <div className="space-y-4">
                {filteredList.length === 0 ? (
                    <div className="text-center py-20 text-slate-400">
                        <ShieldCheck className="w-16 h-16 mx-auto mb-4 opacity-20" />
                        <p className="text-lg font-bold">Tidak ada kendaraan</p>
                    </div>
                ) : filteredList.map(d => (
                    <Card key={d.id} data={d} />
                ))}
            </div>
        </div>
    </div>
  );
};

export default SecurityDashboard;
