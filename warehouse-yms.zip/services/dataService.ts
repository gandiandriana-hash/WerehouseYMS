
import { DriverData, QueueStatus, Gate, Priority, EntryType } from '../types';

const STORAGE_KEY = 'yms_data_v2';

// Initial Mock Data
const INITIAL_DATA: DriverData[] = [
  {
    id: '1',
    name: 'Budi Santoso',
    licensePlate: 'B 1234 XYZ',
    company: 'SBI',
    pic: 'Bu Santi',
    phone: '6281234567890',
    purpose: 'UNLOADING',
    doNumber: 'PO/SBI/2025/001',
    documentFile: 'surat_jalan_budi.jpg',
    entryType: EntryType.WALK_IN,
    checkInTime: Date.now() - 3600000, 
    securityInTime: Date.now() - 3550000,
    status: QueueStatus.LOADING,
    gate: Gate.GATE_2,
    queueNumber: 'A1',
    priority: Priority.NORMAL,
    assignmentTime: Date.now() - 3500000,
    startTime: Date.now() - 900000
  },
  {
    id: '2',
    name: 'Andi Wijaya',
    licensePlate: 'D 5678 ABC',
    company: 'SDI',
    pic: 'Pak Azhari',
    phone: '6281987654321',
    purpose: 'LOADING',
    doNumber: 'PO/SDI/2025/999',
    documentFile: 'sj_andi_scan.pdf',
    entryType: EntryType.BOOKING,
    checkInTime: Date.now() - 1800000,
    securityInTime: Date.now() - 1750000,
    status: QueueStatus.WAITING,
    gate: Gate.GATE_2,
    queueNumber: 'A2',
    priority: Priority.URGENT,
    assignmentTime: Date.now() - 1700000
  },
  {
    id: '3',
    name: 'Rudi Hartono',
    licensePlate: 'L 9999 XX',
    company: 'SRI',
    pic: 'Pak Joko',
    phone: '6285678901234',
    purpose: 'UNLOADING',
    doNumber: 'PO/SRI/2025/055',
    entryType: EntryType.WALK_IN,
    checkInTime: Date.now() - 300000,
    status: QueueStatus.UNASSIGNED,
    gate: Gate.NONE,
    priority: Priority.NORMAL
  }
];

// --- Whatsapp Integration (Mock) ---
const sendWhatsapp = (driver: DriverData, template: string) => {
    // In production, this would call a backend API
    // Ensure phone has no symbols
    const cleanPhone = driver.phone.replace(/\D/g, '');
    console.log(`[WA] Sending ${template} to ${cleanPhone}`);
};

export const getDrivers = (): DriverData[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_DATA));
    return INITIAL_DATA;
  }
  return JSON.parse(stored);
};

export const saveDriver = (driver: DriverData) => {
  const drivers = getDrivers();
  const existingIndex = drivers.findIndex(d => d.id === driver.id);
  if (existingIndex >= 0) {
    drivers[existingIndex] = driver;
  } else {
    drivers.push(driver);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(drivers));
};

// --- DATA MANAGEMENT (DEV TOOLS) ---

export const wipeDatabase = () => {
    localStorage.removeItem(STORAGE_KEY);
    window.location.reload();
};

export const seedDummyData = () => {
    const dummyNames = ['Eko Prasetyo', 'Dedi Kurniawan', 'Siti Aminah', 'Joko Anwar', 'Tono Sutono'];
    const dummyPlates = ['B 9999 AA', 'D 8888 BB', 'L 7777 CC', 'AB 6666 DD', 'F 5555 EE'];
    
    const newDrivers: DriverData[] = dummyNames.map((name, idx) => ({
        id: Math.random().toString(36).substring(2, 9),
        name,
        licensePlate: dummyPlates[idx],
        company: idx % 2 === 0 ? 'SBI' : 'SDI',
        pic: idx % 2 === 0 ? 'Bu Santi' : 'Pak Azhari',
        phone: '628123456789',
        purpose: idx % 2 === 0 ? 'LOADING' : 'UNLOADING',
        doNumber: `PO/${idx % 2 === 0 ? 'SBI' : 'SDI'}/2025/${1000 + idx}`,
        documentFile: 'sample_document.jpg',
        entryType: EntryType.WALK_IN,
        checkInTime: Date.now() - (idx * 1000000),
        status: QueueStatus.UNASSIGNED,
        gate: Gate.NONE,
        priority: Priority.NORMAL
    }));

    const current = getDrivers();
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...current, ...newDrivers]));
    window.location.reload();
};

// --- CRUD OPERATIONS ---

export const createCheckIn = (data: Omit<DriverData, 'id' | 'checkInTime' | 'status' | 'gate' | 'priority' | 'assignmentTime' | 'securityInTime'>): DriverData => {
  const isBooking = data.entryType === EntryType.BOOKING;
  
  const newDriver: DriverData = {
    ...data,
    id: Math.random().toString(36).substring(2, 9),
    checkInTime: Date.now(),
    // Booking status starts as BOOKED, Walk-in starts as UNASSIGNED
    status: isBooking ? QueueStatus.BOOKED : QueueStatus.UNASSIGNED, 
    gate: Gate.NONE,
    priority: Priority.NORMAL
  };
  saveDriver(newDriver);
  return newDriver;
};

export const assignGate = (id: string, gate: Gate, priority: Priority) => {
  const drivers = getDrivers();
  const driver = drivers.find(d => d.id === id);
  if (driver) {
    // Generate simple queue number
    const prefix = gate === Gate.GATE_2 ? 'A' : 'B';
    const existing = drivers.filter(d => d.gate === gate && (d.status === QueueStatus.WAITING || d.status === QueueStatus.LOADING)).length;
    const queueNum = `${prefix}${existing + 1}`;
    
    driver.gate = gate;
    driver.priority = priority;
    driver.status = QueueStatus.WAITING; // Ready to be called
    driver.queueNumber = queueNum;
    driver.assignmentTime = Date.now();
    
    saveDriver(driver);
    sendWhatsapp(driver, 'ASSIGNED');
  }
};

export const updateStatus = (id: string, status: QueueStatus) => {
  const drivers = getDrivers();
  const driver = drivers.find(d => d.id === id);
  if (driver) {
    driver.status = status;
    
    if (status === QueueStatus.CALLED) sendWhatsapp(driver, 'CALLED');
    
    if (status === QueueStatus.LOADING && !driver.startTime) {
      driver.startTime = Date.now();
    }
    if (status === QueueStatus.COMPLETED) {
      driver.endTime = Date.now();
    }
    // Security Gate Out Logic
    if (status === QueueStatus.EXITED) {
      driver.securityOutTime = Date.now();
    }

    saveDriver(driver);
  }
};

// Security Gate In Check
export const securityCheckIn = (id: string) => {
    const drivers = getDrivers();
    const driver = drivers.find(d => d.id === id);
    if (driver) {
        // If they were BOOKED, now they are effectively Walk-in/Unassigned ready for Ops to assign
        // OR if Ops already assigned them, they are just marking arrival
        if (driver.status === QueueStatus.BOOKED) {
            driver.status = QueueStatus.UNASSIGNED;
        }
        driver.securityInTime = Date.now();
        saveDriver(driver);
    }
}

export const getDriverById = (id: string): DriverData | undefined => {
  return getDrivers().find(d => d.id === id);
};
